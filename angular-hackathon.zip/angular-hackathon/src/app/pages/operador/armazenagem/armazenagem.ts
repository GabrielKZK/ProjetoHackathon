// Migrado para angular-mobile-hackathon (src/app/pages/armazenagem). Não é mais
// usado pelo angular-hackathon (gerenciador). Pode ser apagado junto com esta pasta.
export {};
